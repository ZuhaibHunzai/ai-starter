import Tabs from "@/components/tabs";
import Image from "next/image";

export default function Home() {
  return (
    <main className="flex min-h-screen  w-auto   lg:w-8/12 m-auto ">
      <Tabs />
    </main>
  );
}
